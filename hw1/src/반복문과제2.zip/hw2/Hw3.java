package hw2;

public class Hw3 {

	public static void main(String[] args) {
		double sum = 0.0;
		for(double i = 1; i <= 9; i++) {
			sum += i/(i+1);
		}
		System.out.println(sum);
	}
	

}
