package hw1;

public class Q05 {

	public static void main(String[] args) {
		for(int i = 10; i <= 20; i += 2) {
			System.out.println(i);
		}

	}

}
