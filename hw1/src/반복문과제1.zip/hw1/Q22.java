package hw1;

public class Q22 {

	public static void main(String[] args) {
		for(int i = 1; i <= 15; i++) {
			for(int y = 1000; y >= 0; y -= 20) {
				System.out.print('��');
			}
			System.out.println();
		}

	}

}
