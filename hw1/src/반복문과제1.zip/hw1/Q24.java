package hw1;

public class Q24 {
	
	public static void main(String[] args) {
		for(int dan = 3; dan <= 7; dan++) {
			for(int gop = 4; gop <= 8; gop++) {
				System.out.println(dan+" * "+gop+" = "+dan*gop);
			}
		}
	}
}
