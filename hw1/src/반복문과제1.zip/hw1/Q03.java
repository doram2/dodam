package hw1;

public class Q03 {

	public static void main(String[] args) {
		int y1 = 0;
		for(int i = 1; i <= 5; i++) {
			y1 += 1;
			if(i == 1) System.out.println(y1);
		}

	}

}
