package hw1;

public class Q23 {

	public static void main(String[] args) {
		for(int dan = 3; dan <= 8; dan++) {
			for(int gop = 1; gop <= 9; gop++) {
				System.out.println(dan+" * "+gop+" = "+dan*gop);
			}
		}

	}

}
