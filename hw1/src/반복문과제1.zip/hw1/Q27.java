package hw1;

public class Q27 {

	public static void main(String[] args) {
		int dan2 = 7;
		int gop2 = 6;
		
		for(int dan1 = 6; dan1 <= dan2; dan1++) {
			for(int gop1 = 4; gop1 <= gop2; gop1++) {
				System.out.println(dan1+" * "+gop1+" = "+dan1*gop1);
			}
		}

	}

}
