package hw1;

public class Q09 {

	public static void main(String[] args) {
		for(int i = 1; i <= 9; i++) {
			System.out.println("4 * "+i+" = "+4*i);
		}

	}

}
