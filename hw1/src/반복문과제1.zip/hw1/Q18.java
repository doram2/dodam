package hw1;

public class Q18 {

	public static void main(String[] args) {
		for(int i = 0; i < 6; i++) {
			int num = (int)(Math.random()*45 + 1);
			System.out.print(num+" ");
		}

	}

}
