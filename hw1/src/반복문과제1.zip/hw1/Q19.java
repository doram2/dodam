package hw1;

public class Q19 {

	public static void main(String[] args) {
		System.out.println("3 * 2 = "+3*2);
		System.out.println("3 * 3 = "+3*3);
		System.out.println("3 * 4 = "+3*4);
		System.out.println("3 * 5 = "+3*5);

	}

}
