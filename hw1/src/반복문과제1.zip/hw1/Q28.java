package hw1;

public class Q28 {

	public static void main(String[] args) {
		System.out.println("<table>");
		for(int i = 0; i < 4; i++) {
			System.out.println("<tr><td> 1 </td><td> 2 </td><td> 3 </td><td> 4 </td></tr>");
		}
		System.out.println("</table>");

	}

}
