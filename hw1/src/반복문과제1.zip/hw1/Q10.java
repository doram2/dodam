package hw1;

public class Q10 {

	public static void main(String[] args) {
		for(int i = 1; i <= 9; i += 2) {
			System.out.println("6 * "+i+" = "+6*i);
		}
	}

}
