package hw1;

public class Q21 {

	public static void main(String[] args) {
		for(int i = 1; i <= 15; i++) {
			for(int y = 1000; y >= 10; y -= 10) {
				System.out.println("�ڹٴ� ���� ���");
			}
		}

	}

}
