package hw1;

public class Q07 {

	public static void main(String[] args) {
		for(int i = 10; i <= 35; i += 4) {
			System.out.println(i);
		}

	}

}
