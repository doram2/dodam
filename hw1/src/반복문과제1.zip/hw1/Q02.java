package hw1;

public class Q02 {

	public static void main(String[] args) {
		int y = 0;
		for(int i = 1; i <= 10; i++) {
			y += 1;
			System.out.println(y);
		}

	}

}
