package hw1;

public class Q12 {

	public static void main(String[] args) {
		for(int i = 2; i <= 9; i += 2) {
			System.out.println("6 * "+i+" = "+6*i);
		}

	}

}
