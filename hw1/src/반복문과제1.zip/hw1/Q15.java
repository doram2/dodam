package hw1;

public class Q15 {

	public static void main(String[] args) {
		for(int i = 3; i <= 8; i++) {
			System.out.println("6 * "+i+" = "+6*i);
		}

	}

}
