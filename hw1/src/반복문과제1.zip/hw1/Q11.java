package hw1;

public class Q11 {

	public static void main(String[] args) {
		for(int i = 1; i <= 9; i++) {
			if(i % 2 != 0) {
				System.out.println("7 * "+i+" = "+7*i);
			}
		}

	}

}
